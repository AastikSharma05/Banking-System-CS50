#include <bits/stdc++.h>
#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <cstdio>
#include <windows.h>
#include <unistd.h>
using namespace std;
// header files
// class for details of customer
void gotoxy(int,int);
COORD coord={0,0}; // this is global variable 
                                    /*center of axis is set to the top left cornor of the screen*/ 
void gotoxy(int x,int y) 
{ 
    coord.X=x; 
    coord.Y=y; 
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord); 
} 

class customer
{
    char account_no[17];
    char name[25];
    char address[25];
    char phone[11];
    float balance;
    char ac_type[20]; // account type
public:
    void input();        // function to input details
    void display();      // function to display details
    char *ret_ac();      // function to return account no
    float ret_amt();     // function to return balance
    char *ret_type();    // function to return account type
    void upd(float amt); // function to update balance
};
// function to input details
void customer ::input()
{
    system("cls");
    gotoxy(5,3);
    cout << "Account No. : ";
    cin >> account_no;
    gotoxy(5,4);
    cout << "Name : ";
    cin >>name;
    //transform(name.begin(), name.end(),name.begin(), ::toupper);
    gotoxy(5,5);
    cout << "Address : ";
    cin >> address;
    gotoxy(5,6);
    cout << "Phone No. : ";
    cin >> phone;
    gotoxy(5,7);
    cout << "Account Balance : ";
    cin >> balance;
    gotoxy(5,8);
    cout << "Account type:";
     gotoxy(5,9);
    cout<<"1. savings";
     gotoxy(5,10);
    cout<<"2. rd";
     gotoxy(5,11);
    cout<<"3. fd";
     gotoxy(5,12);
    cout<<"Account Type : ";
     gotoxy(5,13);
    cin >> ac_type;
} 
// function to display details
void customer ::display()
{
    
    cout<<endl<<endl;
    cout << "Account No. : ";
    cout << account_no << endl;

    cout << "Name : ";
    //transform(name.begin(), name.end(),name.begin(), ::toupper);
    cout << name << endl;
    cout << "Address : ";
    cout <<address << endl;
    cout << "Phone No. : ";
    cout << phone << endl;
    cout << "Account Balance : ";
    cout << balance << endl;
    cout << "Account Type : ";
    cout << ac_type << endl;
}
// function to return account no
char *customer ::ret_ac()
{
    return account_no;
}
// function to return balance
float customer ::ret_amt()
{
    return balance;
}
// function to return account type
char *customer ::ret_type()
{
    return ac_type;
}
// function to update balance
void customer ::upd(float amt)
{
    balance = amt;
}
// FUNCTION FOR MAKING FRONT PAGE
void front()
{
    system("cls");
    system("color 07");
    gotoxy(15,20);
    for (int i = 0; i < 50; ++i)
        cout << '*';
    int c, r = 20;
    // NEW
    for (int i=0; i<4;i++)
    {
        gotoxy(65,r);
        cout<<'*';
        r++;
    }

    c=65;
    for(int i=0;i<50;i++)
    {
        gotoxy(c,r);
        cout<<'*';
        c--;
    }
    for(int i=0;i<4;i++)
    {
        gotoxy(c,r);
        cout<<'*';
        r--;
    }
    gotoxy(30,22);
    cout << "WELCOME TO SABKA BANK";
    cout<<"\n\n\n\n\t\t\t\t\t\tPress any key to continue ";
    getch();
    
}

// function for making box

void box(int c1,int r1, int c2, int r2)
{
    for(int i=c1;i<=c2;++i)  //for row 1
	{
        gotoxy(i,r1);
		cout<<(char)196;
		
	}
	cout<<(char)191;    //top right

	for(int j=r1+1; j<=r2-1;++j) //for column 2
	{   
        gotoxy(c2+1,j);
		cout<<(char)179;		
	}
	gotoxy(c2+1,r2);
	cout<<(char)217;       //bottom right

	for(int k=c2;k>=c1;--k)   //for row 2
	{
        gotoxy(k,r2);
		cout<<(char)196;		
	}
	gotoxy(c1,r2);
	cout<<(char)192;      //bottom left

	for(int l=r2-1; l>=r1+1;--l)     //for column 1
	{
        gotoxy(c1,l);
		cout<<(char)179;
	}
	gotoxy(c1,r1);
	cout<<(char)218;      //top left
}


// function for loading
void load()
{   
    system("cls");
    system("color 0F");
    gotoxy(32,7);
   system("cls");
    char a = 177;
    char b = 219;
    // system("color 0A");
    cout << "\n\n\n\t\t\t\tPlease wait while loading....\n\n";
    cout << "\t\t\t\t";
    for (int i = 0;i <= 50;i++)
         cout << a;

    cout << "\r";
    cout << "\t\t\t\t";
    for (int i = 0;i <= 50;i++)
    {
        cout << b;
        for (int j = 0;j <= 1e8;j++);
    }
}
// function for password
void password()
{
    system("cls");

    system("color 94");
    char pass[10] = "cs50", p[10];
    int i;

    cout << "\n\n\t\t\t\t\tEnter your Password : ";

    for (i = 0; p[i] != 13; i++)
    {
        p[i] = getch();
        if (p[i] == 13)
            break;

        cout << "*";
    }
    p[i] = '\0';
    cout << "\n";

    if (strcmp(pass, p))
    {
        cout << "\n";
        cout << " ";
system("color D4");
system("cls");
        printf("%s", "INCORRECT PASSWORD");
        getch();
        exit(0);
    }
    else
    {
        system("cls");
        cout << "\n";
        cout << " ";
        gotoxy(22,3);
        system("color D6");
        printf("%s", "CORRECT PASSWORD");
        sleep(1);
        system("cls");
        cout << endl;
        cout << "\n";
        cout << " ";
gotoxy(22,3);
system("color A4");
        printf("%s", "LOGIN ACCESSED !!!");
        sleep(1);
        load(); // call statement of laoding function
    }
}
// function for cash withdrawl
void withdrawl()
{
    system("cls");
   
    box(10,3,55,17);
    customer c;
    float amount;
    int flag = 0;
    char ac[17];
    gotoxy(20,5);
    cout << "\naccount no. : ";
    cin >> ac;
    gotoxy(15,7);
    cout << "how much amount you want to withdraw: ";
    gotoxy(25,9);
    cin >> amount;
    char account[17];
    float amt;
    fstream file;
    int count = 0;
    file.open("ban1.dat", ios::in | ios::out | ios::binary);
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        if (!file)
            break;
        count++;
        strcpy(account, c.ret_ac());
        if (!strcmpi(account, ac))
        {
            flag = 1;
            amt = c.ret_amt();
            amt -= amount;
            c.upd(amt);
            file.seekp((count - 1) * sizeof(c));
            file.write((char *)&c, sizeof(c));
            break;
        }
    }
    if (flag == 0)
    {gotoxy(15,11);
        cout << "\nthis account details does not exist";
        getch();
    }
    else if (flag == 1)
    {gotoxy(15,11);
        cout << "\namount withdrawal successfully !!!";
gotoxy(20,13);
        cout << "\nyour balance : " << amt;
        getch();
    }
    file.close();
}
// function for deposit through cash
void cash()
{
box(10,3,55,17);
    customer c;
    int flag = 0;
    float amount;
    char ac[17];
gotoxy(20,5);
    cout << "\naccount no. : ";
    cin >> ac;
gotoxy(15,7);
    cout << "\nhow much amount you want to deposit: ";
gotoxy(25,9);
    cin >> amount;
    float amt;
    int count = 0;
    char account[17];
    fstream file;
    file.open("ban1.dat", ios::out | ios::in | ios::binary);
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        count++;
        strcpy(account, c.ret_ac());
        if (!strcmpi(account, ac))
        {
            flag = 1;
            amt = c.ret_amt();
            amt += amount;
            c.upd(amt);
            file.seekp((count - 1) * sizeof(c));
            file.write((char *)&c, sizeof(c));
            break;
        }
    }
gotoxy(15,11);
    if (flag == 1)
    {
        cout << "\nAmount Deposited successfully !!!";
	gotoxy(20,13);
        cout << "\nCurrent balance : " << amt;
    }
    else if (flag == 0)
        cout << "\nthis account does not exist !!!";
    getch();
    file.close();
}
// function for account statement generation
void generation()
{
    customer c;
    char ac[17];
    int flag = 0;
gotoxy(2,1);
    cout << "\nEnter the Account no. whose statement to be generated account no. : \t";
    cin >> ac;
    char account[17];
    fstream file;
    file.open("ban1.dat", ios::in | ios::binary);
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        if (!file)
            break;
        strcpy(account, c.ret_ac());
        if (!strcmpi(account, ac))
        {
            flag = 1;
            cout<<endl<<endl;
            c.display();
            getch();
        }
    }
    if (flag == 0)
        cout << "\nthis account details does not exist";
    file.close();
}
// function for account to account transfer
void transfer()
{
    customer c;
    int flag = 0;
    float amount;
    char ac1[17], ac2[17];
    box(5,7,70,20);
    cout << "\naccount no. from where money is to be transfer : ";
    cin >> ac1;
    cout << "\n\naccount no. where the money is transferred : ";
    cin >> ac2;
    cout << "\n\nhow much amount you want to transfer : \t";
    cin >> amount;
    float amt;
    int count = 0;
    fstream file;
    file.open("ban1.dat", ios::in | ios::out | ios::binary);
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        if (!file)
            break;
        count++;
        if (!strcmpi(ac1, c.ret_ac()))
        {
            flag = 1;
            amt = c.ret_amt();
            amt -= amount;
            c.upd(amt);
            file.seekp((count - 1) * sizeof(c));
            file.write((char *)&c, sizeof(c));
        }
    }
    file.close();
    file.open("ban1.dat", ios::in | ios::out | ios::binary);
    count = 0;
    if (flag == 1)
        while (!file.eof())
        {
            file.read((char *)&c, sizeof(c));
            if (!file)
                break;
            count++;
            if (!strcmpi(ac2, c.ret_ac()))
            {
                amt = c.ret_amt();
                amt += amount;
                c.upd(amt);
                file.seekp((count - 1) * sizeof(c));
                file.write((char *)&c, sizeof(c));
            }
        }
    cout << endl;
    system("color 2F");
gotoxy(17,24);
    cout << "Account "<<ac1;
system("color 2F");
    printf("%s", " >>>>>> ");
    cout << " Transfering Rs. " << amount;
system("color 2F");
sleep(1);
    printf("%s", " >>>>>> ");
    cout<<" Account "<<ac2<<" \t Transfer Succesfully Done!!";
    getch();
    file.close();
}
// function to add a customer
void add()
{
    
    customer c;
    char ch = 'y';
    fstream file;
    file.open("ban1.dat", ios::app | ios::binary);
    while (ch == 'y' || ch == 'Y')
    {
        c.input();
        file.write((char *)&c, sizeof(c));
            gotoxy(5,14);
        cout << "DO YOU WANT ADD MORE RECORDS? (Y/N)" << endl;
         gotoxy(5,15);
        cin >> ch;
    }
    file.close();
}
// function to modify details of customer
void modify()
{

    fstream file;
    char ac[17];
    customer c;
    int counter = 0;
    file.open("ban1.dat", ios::in | ios::out | ios::binary);
    gotoxy(15,7);
    cout << "Enter the Account no. whose account details are to be modified";
    gotoxy(30,10);
    cout << "account no. : ";
    cin >> ac;
    system("cls");
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        if (!file)
          {  break;
        counter++;}
        if (!strcmpi(c.ret_ac(), ac))
        {
            file.seekp((counter - 1) * sizeof(c));
            c.input();
            file.write((char *)&c, sizeof(c));
        }
    }
    file.close();
}
// function to delete the record of customer
void del()
{
    fstream file, tfile;
    file.open("ban1.dat", ios::in | ios::binary);
    tfile.open("details.dat", ios::out | ios::binary);
    customer c;
    char ac[17];
    cout << "\nEnter the Account no. whose account is to be deleted";
    cout << "\naccount no. : ";
    cin >> ac;
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        
        if (strcmpi(c.ret_ac(), ac))
        {
            tfile.write((char *)&c, sizeof(c));
        }
    }
gotoxy(25,20);
    cout << "\n account deleted successfully !!!";
    getch();
    file.close();
    tfile.close();
    remove("ban1.dat");
    rename("details.dat", "ban1.dat");
}
// function to display the list of customers
void disp()
{
    
    fstream file;
    file.open("ban1.dat", ios::in | ios::binary);
    customer c;
    int i = 0;
    while (!file.eof())
    {
        i++;
        file.read((char *)&c, sizeof(c));
        if (!file)
            break;
        cout << "\nDetails of customer " << i << endl;
        c.display();
        cout << endl;
    }
    file.close();
}
// function to display the list of customer whose minimum balance is 5000
void fine()
{
    fstream file;
    file.open("ban1.dat", ios::in | ios::binary);
    customer c;
    int i = 0, flag = 0;
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        if (!file)
            break;
        if (c.ret_amt() < 5000)
        {
            flag = 1;
            i++;
            cout << i << ". ";
            c.display();
        }
    }
    if (flag == 0)
        cout << "\n no account with balance below 5000 exist !!!";
    file.close();
}
// function to add interest
void interest()
{
    customer c;
    int count = 0, flag = 0;
    float ri; // ri=rate of interest
    float amt;
    char ac[17];
    box(10,7,50,22);
    gotoxy(20,10);
    fstream file;
    file.open("ban1.dat", ios::in | ios::out | ios::binary);
    while (!file.eof())
    {
        file.read((char *)&c, sizeof(c));
        count++;
        if (!file)
            break;
        // if (!(strcmpi(ac, c.ret_ac())))
        else
        {
            flag = 1;
            if (!(strcmpi(c.ret_type(), "fd")))
            {
                amt = c.ret_amt();
                ri = (7.0 / 100) * amt;
                amt += ri;
                
            }
            else if (!strcmpi(c.ret_type(), "savings"))
            {
                amt = c.ret_amt();
                ri = (6.0 / 100) * amt;
                amt += ri;
                
            }
            else if (!strcmpi(c.ret_type(), "rd"))
            {
                amt = c.ret_amt();
                ri = (8.0 / 100) * amt;
                amt += ri;
                
            }
            if (flag == 1)
            {
                c.upd(amt);
                file.seekp((count - 1) * sizeof(c));
                file.write((char *)&c, sizeof(c));
            }
        }
    }

  gotoxy(15,15);
cout<<"AMOUNT UPDATED SUCCESSFULLY  !!!"<<endl;
    file.close();
}
// function for menu
void menu()
{
    front();
    password();
    cout << endl;
    int choice;
    system("cls");

    do
    {
        system("color 60");
        system("cls");
        box(20,2,60,25);
        gotoxy(22,3);
        cout<<"1. Cash Withdrawl."<<endl;
        gotoxy(22,5);
        cout<<"2. Cash Deposit."<<endl;
        gotoxy(22,7);
        cout<<"3. Account Statement Generation."<<endl;
        gotoxy(22,9);
        cout<<"4. Account to Account Transfer."<<endl;
        gotoxy(22,11);
        cout<<"5. Add a Customer."<<endl;
        gotoxy(22,13);
        cout<<"6. Modify Details of Customer."<<endl;
        gotoxy(22,15);
        cout<<"7. Delete Details of Customer."<<endl;
        gotoxy(22,17);
        cout<<"8. Display List of Customers."<<endl;
        gotoxy(22,19);
        cout<<"9. Diplay List of Customers whose ";
        gotoxy(26,20);
        cout<<"Minimum Balance is Rs.5000."<<endl;
        gotoxy(22,22);
        cout<<"10. Adding Interest."<<endl;
        gotoxy(22,24);
        cout<<"11. Exit."<<endl;
        gotoxy(29,25);
        cout << "Enter Your Choice : ";
        cin >> choice;
        switch (choice)
        {
        case 1:
        {
            system("cls");
            withdrawl();
            break;
        }
        case 2:
        {
            system("cls");
            cash();
            break;
        }
        case 3:
        {
            system("cls");
            generation();
            break;
        }
        case 4:
        {
            system("cls");
            transfer();
            break;
        }
        case 5:
        {
            system("cls");
            add();
            break;
        }
        case 6:
        {
            system("cls");
            modify();
            break;
        }
        case 7:
        {
            system("cls");
            del();
            break;
        }
        case 8:
        {
            system("cls");
            disp();
             getch();
            break;
        }
        case 9:
        {
            system("cls");
            fine();
            getch();
            break;
        }
        case 10:
        {
            system("cls");
            interest();
            getch();
            break;
        }
        case 11:
            exit(0);
        default:
            cout << "invalid option!!!";
        }
    } while (choice < 12);
}
// main function
int main()
{
    system("cls");
    menu();
    return 0;
}